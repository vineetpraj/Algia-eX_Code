from flask_wtf import FlaskForm
from wtforms import (
    StringField,
    SubmitField,
    IntegerField,
    DecimalField,
    SelectField,
)
from wtforms.validators import DataRequired, Length, Email, EqualTo

"""
p_map = {'name':'Robert Downey',
 'age':51,
 'sex':'M',
 'height':'1.81',
 'weight':'56',
 'tenderness':'0',
 'disease':'0',
 'workduration':'0',
 'accident':'0',
 'posture':'0',
 'rest':'0',
 'profession':'0'}}
"""
class UserForm(FlaskForm):

    name = StringField("Full Name", validators=[DataRequired()])

    age = IntegerField("Age", validators=[DataRequired()])
    
    weight = IntegerField("Weight", validators=[DataRequired()])

    height = DecimalField("Height in meters", validators=[DataRequired()])

    sex = SelectField(
        "Sex",
        choices=[("M", "Male"), ("F", "Female")],
        validators=[DataRequired()],
    )
    tenderness = SelectField(
        "With the help of a relative ask them to Press on these points and check if you feel pressure and pain both and write the no. of such points below.(from the range of 1 to 18)?",
        choices=[("0", "No"), ("1", "Yes")],
        validators=[DataRequired()],
    )

    disease = SelectField(
        "Do you have any have any of these diseases(Arthritis,Osteoporosis,Tumors,Burisitis,Sciatica)?",
        choices=[("0", "No"), ("1", "Yes")],
        validators=[DataRequired()],
    )

    workduration = SelectField(
        "Do you work continuously in slots more than 20 minutes 8 times during your work day without taking rest?",
        choices=[("0", "No"), ("1", "Yes")],
        validators=[DataRequired()],
    )

    accident = SelectField(
        "Have you gone through any Stressful or traumatic events, such as car accidents, post-traumatic stress disorder (PTSD)?",
        choices=[("0", "No"), ("1", "Yes")],
        validators=[DataRequired()],
    )
    posture = SelectField(
        "In which posture do you sit for a long time that can effect on your body and you experience pain in the same area?",
        choices=[("0", "No"), ("1", "Yes")],
        validators=[DataRequired()],
    )

    rest = SelectField(
        "Does your pain go away when you take a proper rest?",
        choices=[("0", "No"), ("1", "Yes")],
        validators=[DataRequired()],
    )
    profession = SelectField(
        "The area in which you are having pain is used you most of the time due to your profession. If not in present so in last 5 or 10 years?",
        choices=[("0", "No"), ("1", "Yes")],
        validators=[DataRequired()],
    )

    submit = SubmitField("Submit")
