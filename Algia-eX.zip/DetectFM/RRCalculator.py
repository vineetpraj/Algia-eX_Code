x =int(input("Enter the no. of subjects of test group: "))
y =int(input("Enter the no. of subjects of control group: "))
X = int(input("Enter the no. of subjects of test group with the factor: "))
Y = int(input("Enter the no. of subjects of control group with the factor: "))
# risk in test group 
RTest = (X/x)
# risk in control group 
RControl = (Y/y)
RR_value =(RTest/RControl)
print(RR_value)
