# Importing Pandas for csv processing
import pandas as pd
# p_map is a dictionary containing the basic retrospective & dietary information of the patient
p_map = {'name':'Robert Downey',
 'age':51,
 'sex':'M',
 'height':1.81,
 'weight':56,
 'tenderness':0,
 'disease':0,
 'workduration':1,
 'posture':1,
 'rest':1,
 'profession':1,
 'accident':1,
}

rr_map = {
    "age":1.00,
    "sex":0.19,
    "tenderness":0.20,
    "disease":0.41,
    "workduration":1.06,
    "accident":0.55,
    "posture":1.12,
    "rest":0.82,
    }

# Importing the dataset into the dataframe according to Age, Sex & Region
# All datasets obtained from http://gco.iarc.fr/today/

init_risk = ()

def calculate_init_risk(p_map):
    #Calculate the Initial Risk depending upon sex and age
    if (p_map["age"]) >= 35 and p_map['sex'] == "F":
        init_risk = 1.19
    else:
        init_risk = 0.1
    
    print("Initial Risk of developing Fibromyalgia due to your age and sex is",init_risk,)  
    regional_risk =init_risk

    increase = float()
    # 3. Calculate Risk Increase due to obesity (BMI>25)
    p_bmi = float (p_map['weight'])/(float (p_map['height'])**2)
    if p_bmi >= 25:
        increase += init_risk

# Calculate the increased risk due to diseases
    for i in p_map["disease"]:
        i= int()
        if p_map["disease"][i] ==1:
            increase += init_risk * (rr_map["disease"][i]-1)
# Calculate the increased risk due to workduration
    for p in p_map["workduration"]:
        p= int()
        if p_map["workduration"][p] ==1:
            increase += init_risk * (rr_map["workduration"][p]-1)

    for f in p_map["tenderness"]:
        f= int()
        if p_map["tenderness"][f] ==1:
            increase += init_risk * (rr_map["tenderness"][f]-1)

    for d in p_map["accident"]:
        d= int()
        if p_map["accident"][d] ==1:
            increase += init_risk * (rr_map["accident"][d]-1)

    for l in p_map["posture"]:
        l= int()
        if p_map["posture"][l] ==1:
            increase += init_risk * (rr_map["posture"][l]-1)

    for m in p_map["rest"]:
        m= int()
        if p_map["rest"][m] ==1:
            increase += init_risk * (rr_map["rest"][m]-1)

    r_type = 0
    p_increase = (increase + init_risk) / init_risk
    if p_increase >= 1:
        r_type = "substantially high risk increase"
    elif p_increase >= 0.8:
        r_type = "moderately/mildly high risk increase"
    else:
        r_type = "no such risk increase"
    return init_risk, increase, regional_risk, r_type
    
def return_results(init_risk, regional_risk, increase, r_type, p_map):
    p1 = (
        "Your initial (unchangable) risk of developing Fibromyalgia in your lifetime due to your age, sex is:"
        + str(init_risk)
        + "%"
    )
    p2 = (
        "You have a "
        + r_type
        + " risk for Fibromyalgia due to your lifestyle and work duration."
        + " Your (%) risk increase is "
        + str((init_risk + increase) / init_risk)
    )
    p4 = "If you'd like to reduce your risk than try switching to a well lifestyle, reduce physical exertion. Try to perform some exercise for physical mobility!"

    if r_type == "substantially high risk increase":
        p3 = "If you are observing Fibromyalgia symptoms such as fatigye, pain and proliferation of tender points etc. than you should definitely consult a Orthopaedician."
    else:
        p3 = "As you don't have a Substantially high risk for Fibromyalgia, it is not compulsory to to visit an orthopaedic."

    return p1, p2, p3, p4, r_type
