import os
from dotenv import load_dotenv
from flask import Flask, render_template, url_for, flash, redirect
from forms import UserForm
import risk_algorithm

load_dotenv()

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY")

p_info = {}


@app.route("/", methods=["GET", "POST"])
@app.route("/home", methods=["GET", "POST"])
def home():
    form = UserForm()

    if form.validate_on_submit():
        # a.append(form.username.data)

        p_info.update(
            {
                "name": form.name.data,
                "age": int(form.age.data),
                "height": float(form.height.data),
                "weight": float(form.weight.data),
                "sex": form.sex.data,
                "workduration": form.workduration.data,
                "accident": form.accident.data,
                "rest": form.rest.data,
                "profession": form.profession.data,
                "posture": form.posture.data,
                "disease": form.disease.data,
                "tenderness": form.tenderness.data,
            
            }
        )

        flash(f"Information submitted for {form.name.data}!", "success")
        return redirect(url_for("results"))

    return render_template("home.html", form=form)


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/results", methods=["GET", "POST"])
def results():
    init_risk, increase, regional_risk, r_type = risk_algorithm.calculate_init_risk(
        p_map=p_info
    )
    # print(p_info, init_risk, increase)
    p1, p2, p3, p4, r_type = risk_algorithm.return_results(
        init_risk=init_risk,
        regional_risk=regional_risk,
        increase=increase,
        r_type=r_type,
        p_map=p_info,
    )

    if r_type == "substantially high risk increase":
        color = "p-3 mb-2 bg-danger text-white"
    elif r_type == "moderately/mildly high risk increase":
        color = "p-3 mb-2 bg-warning text-dark"
    else:
        color = "p-3 mb-2 bg-success text-white"

    return render_template(
        "results.html",
        name=p_info["name"],
        p1=p1,
        p2=p2,
        p3=p3,
        p4=p4,
        color=color,
    )


if __name__ == "__main__":
    app.run(debug=True)
